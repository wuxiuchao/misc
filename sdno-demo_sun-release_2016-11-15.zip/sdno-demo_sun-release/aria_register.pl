#!/usr/bin/perl

sub readFile {
  my ($filename) = @_;

  local $/=undef;
  open FILE, $filename or die "Couldn't open file $filename: $!";
  my $content = <FILE>;
  close FILE;

  return $content;
}



$MSB_ADDR=$ARGV[0];
$ARIA_IP=$ARGV[1];


$ARIA_REG_FILENAME = "registration/Reg_aria.json";
$ARIA_IP_PLACE_HOLDER = "ARIA_IP";


my $msb_url = "/openoapi/microservices/v1/services";



##############Register ARIA to MSB
my $aria_content = readFile($ARIA_REG_FILENAME);
$aria_content =~ s/$ARIA_IP_PLACE_HOLDER/$ARIA_IP/;
my $aria_content_in_curl = "'".$aria_content."'";

my $aria_reg_command = "curl -X POST -d ".$aria_content_in_curl." -H 'Content-Type: application/json;charset=UTF-8' http://".$MSB_ADDR.$msb_url;
print $aria_reg_command."\n";

my $aria_reg_response = `$aria_reg_command`;
print $aria_reg_response."\n";


