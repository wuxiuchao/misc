#/bin/bash

source ./openo-docker-functions.sh

#container names
CONTAINERS=(i-msb i-dm i-esr i-auth i-protocolstack
            i-catalog i-inventory i-wso2ext i-aria i-model-designer 
            i-gso-gateway i-gso-manager
            i-sdnos-mss i-sdnos-brs
            i-sdnos-nslcm i-sdnos-overlay i-sdnos-sfc i-sdnos-vpc i-sdnos-vxlan i-sdnos-ipsec
            i-sdnos-monitor i-sdnos-optimize i-sdnos-l2vpn i-sdnos-l3vpn i-sdnos-vsitemgr
            i-sdnod-hw-openstack i-sdnod-hw-overlay #i-sdnod-hw-sfc
            i-sdnod-ct-te i-sdnod-hw-l3vpn i-sdnod-zte-sptn
            )

#images names used when pulling from docker hub.
IMAGES=(common-services-msb:1.0.0 common-services-drivermanager:1.0.0 common-services-extsys:1.0.0 common-services-auth:1.0.0 common-services-protocolstack:1.0.0 
        common-tosca-catalog:1.0.0 common-tosca-inventory:1.0.0 common-services-wso2ext:1.0.0 common-tosca-aria:1.0.0 common-tosca-modeldesigner:1.0.0
        gso-service-gateway:1.0.0 gso-service-manager:1.0.0
        sdno-service-mss:1.0.0 sdno-service-brs:1.0.0
        sdno-service-nslcm:1.0.0 sdno-service-overlayvpn:1.0.0 sdno-service-servicechain:1.0.0 sdno-service-vpc:1.0.0 sdno-service-vxlan:1.0.0 sdno-service-ipsec:1.0.0
        sdno-monitoring:1.0.0 sdno-optimize:1.0.0 sdno-service-l2vpn:1.0.0 sdno-service-l3vpn:1.0.0 sdno-vsitemgr:1.0.0
        sdno-driver-huawei-openstack:1.0.0 sdno-driver-huawei-overlay:1.0.0 #sdno-driver-huawei-servicechain:1.0.0
        sdno-driver-ct-te:1.0.0 sdno-driver-huawei-l3vpn:1.0.0 sdno-driver-zte-sptn:1.0.0
        )


#IP addresses used by each container
IPS=(172.16.77.2 172.16.77.3 172.16.77.4  172.16.77.5 172.16.77.6
     172.16.77.12 172.16.77.13 172.16.77.14  172.16.77.15 172.16.77.16
     172.16.77.22 172.16.77.23 
     172.16.77.32 172.16.77.33 
     172.16.77.42 172.16.77.43 172.16.77.44 172.16.77.45 172.16.77.46 172.16.77.47
     172.16.77.52 172.16.77.53 172.16.77.54 172.16.77.55 172.16.77.56
     172.16.77.62 172.16.77.63 #172.16.77.64
     172.16.77.72 172.16.77.73 172.16.77.74)


#The address of MSB and the address of mysql used by NSLCM, i.e., common-tosca-inventory.     
MSB_IPPORT=172.16.77.2:80
NSLCM_MYSQL_ADDR=172.16.77.13:3306


#clean all docker containers, recreate the network for open-o
docker_clean_all
sudo docker network rm openo
sudo docker network create --subnet=172.16.77.0/24 openo

#get the latest docker images for all common-o, gs-o, sdn-o services.
docker_sync_all

#start all services one by one
docker_start_all

#stop all docker containers. you can then use "study_portal-controllers.sh" to start the containers needed to demonstrate the provision of the site2DC service.
sudo docker stop $(sudo docker ps -a -q)