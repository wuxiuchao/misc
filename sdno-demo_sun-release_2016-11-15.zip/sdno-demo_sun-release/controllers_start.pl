#!/usr/bin/perl
sub readFile {
  my ($filename) = @_;

  local $/=undef;
  open FILE, $filename or die "Couldn't open file $filename: $!";
  my $content = <FILE>;
  close FILE;

  return $content;
}



my @controller_names = ("AcBranchController", "AcDcController");
my @ports = ("10001", "10002");
my @shutdown_ports = ("20001", "20002");

foreach my $i (0 .. $#controller_names) {
    ###############start the moco server
    my $simu_fn = "simulation/".$controller_names[$i].".json";
    my $logfile_name = "tmp/".$controller_names[$i]."_log.txt";
    my $run_command = "java -jar moco-runner-0.11.0-standalone.jar ";
    if($controller_names[$i] eq "AcBranchController") {
        $run_command = $run_command."https -p ".$ports[$i]." -c ".$simu_fn." -s ".$shutdown_ports[$i]." --https simulation/cert.jks --cert mocohttps --keystore mocohttps >".$logfile_name." &";
    } else {
        $run_command = $run_command."http -p ".$ports[$i]." -c ".$simu_fn." -s ".$shutdown_ports[$i]." >".$logfile_name." &";
    }

    print $run_command."\n";
    system $run_command;
    sleep(3);
}