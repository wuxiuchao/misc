sudo docker stop i-esr
sudo docker rm i-esr
sudo docker run -d -t --name i-esr --network openo-net --ip 172.18.0.4 -e MSB_ADDR=172.18.0.2 openoint/common-services-extsys:1.0.0
