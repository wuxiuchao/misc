#!/usr/bin/perl
use JSON qw( decode_json encode_json);

sub readFile {
  my ($filename) = @_;

  local $/=undef;
  open FILE, $filename or die "Couldn't open file $filename: $!";
  my $content = <FILE>;
  close FILE;

  return $content;
}



$MSB_ADDR=$ARGV[0];
$SIMULATOR_IP=$ARGV[1];


$SFC_DRIVER_SIMU_FILENAME = "tmp/SfcDriver.json";
$SFC_DRIVER_SIMU_DIR = "SfcDriver";
$DRIVER_PLACE_HOLDER = "DRIVER_IP";

$DRIVER_LISTEN_PORT = "8542";
$DRIVER_SHUTDOWN_PORT = "18542";

my $dm_url = "/openoapi/drivermgr/v1/drivers";





##############merge all request-response pairs into one json file to be used by moco-server.
open(my $out_fh, '>', $SFC_DRIVER_SIMU_FILENAME) or die "Could not open file: $!";
print $out_fh "[\n";
my @all_simu_filenames = glob($SFC_DRIVER_SIMU_DIR.'/*.json');
foreach my $i (0 .. $#all_simu_filenames) {
    my $content = readFile($all_simu_filenames[$i]);
    if($i==$#all_simu_filenames) {
        print $out_fh $content."\n";
    } else {
        print $out_fh $content.",\n";
    }
}
print $out_fh "]";
close $out_fn;

##############start the driver for SFC
my $run_command = "java -jar moco-runner-0.11.0-standalone.jar http -p ".$DRIVER_LISTEN_PORT." -c ".$SFC_DRIVER_SIMU_FILENAME." -s ".$DRIVER_SHUTDOWN_PORT." &";
print $run_command."\n";
system $run_command;
sleep(3);

##############Register SFC Driver to Driver Manager
my $driver_reg_fn = "registration/Reg_SfcDriver.json";
my $driver_content = readFile($driver_reg_fn);
$driver_content =~ s/$DRIVER_PLACE_HOLDER/$SIMULATOR_IP/;
my $driver_content_in_curl = "'".$driver_content."'";

my $driver_reg_command = "curl -X POST -d ".$driver_content_in_curl." -H 'Content-Type: application/json;charset=UTF-8' http://".$MSB_ADDR.$dm_url;
print $driver_reg_command."\n";

my $driver_reg_response = `$driver_reg_command`;
print $driver_reg_response."\n";


