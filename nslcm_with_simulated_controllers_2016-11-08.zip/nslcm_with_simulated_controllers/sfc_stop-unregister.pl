#!/usr/bin/perl
use JSON qw( decode_json encode_json);

sub readFile {
  my ($filename) = @_;

  local $/=undef;
  open FILE, $filename or die "Couldn't open file $filename: $!";
  my $content = <FILE>;
  close FILE;

  return $content;
}



$MSB_ADDR=$ARGV[0];

$SFC_CONTROLLER_ID_FILENAME = "tmp/sfc_controller_id.txt";

$DRIVER_SHUTDOWN_PORT = "22001";

my $dm_url = "/openoapi/drivermgr/v1/drivers";

my $esr_url = "/openoapi/extsys/v1/sdncontrollers";


##############stop the simulated driver for SFC
my $stop_command = "java -jar moco-runner-0.11.0-standalone.jar shutdown -s ".$DRIVER_SHUTDOWN_PORT;
print $stop_command."\n";
system $stop_command;

##############Unregister SFC Driver from Driver Manager
my $driver_reg_fn = "registration/Reg_SfcDriver.json";
my $driver_content = readFile($driver_reg_fn);
my $driver_reg = decode_json($driver_content);
my $driver_id = $driver_reg->{"driverInfo"}->{"instanceID"};

my $driver_unreg_command = "curl -X DELETE "."http://".$MSB_ADDR.$dm_url."/".$driver_id;
print $driver_unreg_command."\n";

my $driver_unreg_response = `$driver_unreg_command`;
print $driver_unreg_response."\n";




##############Unregister related, but non-existent controllers from ESR
my $content = readFile($SFC_CONTROLLER_ID_FILENAME);
my @ids = split(/:/, $content);
foreach my $id (@ids) {
    my $unreg_command = "curl -X DELETE http://".$MSB_ADDR.$esr_url."/".$id;
    print $unreg_command."\n";

    my $unreg_response = `$unreg_command`;
    print $unreg_response."\n";
}
