#/bin/bash

source ./openo-docker-functions.sh

CONTAINERS=(i-msb i-dm i-esr i-auth i-protocolstack
            i-catalog i-inventory i-wso2ext i-aria i-model-designer 
            i-gso-gateway i-gso-manager
            i-sdnos-mss i-sdnos-brs
            i-sdnos-nslcm i-sdnos-overlay i-sdnos-sfc i-sdnos-vpc i-sdnos-vxlan i-sdnos-ipsec
            i-sdnos-monitor i-sdnos-optimize i-sdnos-l2vpn i-sdnos-l3vpn i-sdnos-vsitemgr
            i-sdnod-hw-openstack i-sdnod-hw-overlay i-sdnod-hw-sfc
            i-sdnod-ct-te i-sdnod-hw-l3vpn i-sdnod-zte-sptn
            )


IMAGES=(common-services-msb common-services-drivermanager common-services-extsys common-services-auth common-services-protocolstack 
        common-tosca-catalog common-tosca-inventory common-services-wso2ext common-tosca-aria common-tosca-modeldesigner
        gso-service-gateway gso-service-manager
        sdno-service-mss sdno-service-brs
        sdno-service-nslcm sdno-service-overlayvpn sdno-service-servicechain sdno-service-vpc sdno-service-vxlan sdno-service-ipsec
        sdno-monitoring sdno-optimize sdno-service-l2vpn sdno-service-l3vpn sdno-vsitemgr
        sdno-driver-huawei-openstack sdno-driver-huawei-overlay sdno-driver-huawei-servicechain
        sdno-driver-ct-te sdno-driver-huawei-l3vpn sdno-driver-zte-sptn
        )



IPS=(172.18.0.2 172.18.0.3 172.18.0.4  172.18.0.5 172.18.0.6
     172.18.1.2 172.18.1.3 172.18.1.4  172.18.1.5 172.18.1.6
     172.18.2.2 172.18.2.3 
     172.18.3.2 172.18.3.3 
     172.18.4.2 172.18.4.3 172.18.4.4 172.18.4.5 172.18.4.6 172.18.4.7
     172.18.5.2 172.18.5.3 172.18.5.4 172.18.5.5 172.18.5.6
     172.18.6.2 172.18.6.3 172.18.6.4
     172.18.7.2 172.18.7.3 172.18.7.4)

MSB_IPPORT=172.18.0.2:80
NSLCM_MYSQL_ADDR=172.18.1.3:3306

stop=$@
if [ "$stop" == "stop" ]
then
    docker_clean_all
else
    docker_clean_all
    #docker_sync_all
    docker_start_once_for_all
    sudo docker stop $(sudo docker ps -a -q)
fi
