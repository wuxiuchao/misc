#!/bin/bash

./reboot-esr_clean.sh
./controllers_register.pl 172.18.0.2 172.18.0.1

./reboot-mss_insert-data.sh
./repopulate_request.pl
