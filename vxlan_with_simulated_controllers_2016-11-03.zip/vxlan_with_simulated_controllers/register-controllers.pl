#!/usr/bin/perl
use JSON qw( decode_json encode_json);

sub readFile {
  my ($filename) = @_;

  local $/=undef;
  open FILE, $filename or die "Couldn't open file $filename: $!";
  my $content = <FILE>;
  close FILE;

  return $content;
}



$MSB_ADDR=$ARGV[0];
$SIMULATOR_IP=$ARGV[1];

$ID_OUTPUT_FILENAME = "tmp/controller-id.json";
$SHUTDOWN_OUTPUT_FILENAME = "tmp/shutdown.txt";

$PLACE_HOLDER = "CONTROLLER_IPPORT";
my @controller_names = ("AcBranchController");
my @ports = ("10001");
my @shutdown_ports = ("20001");
my @api_urls = ("/openoapi/extsys/v1/sdncontrollers");
my @id_keynames = ("sdnControllerId");



open(my $controller_id_fh, '>', $ID_OUTPUT_FILENAME) or die "Could not open file: $!";
print $controller_id_fh "{\n";


$first=1;
foreach my $i (0 .. $#controller_names) {

    ##############register controller to ESR.
    my $reg_fn = "registration/Reg_".$controller_names[$i].".json";
    my $info = readFile($reg_fn);

    my $real_address = $SIMULATOR_IP.":".$ports[$i];
    $info =~ s/$PLACE_HOLDER/$real_address/;
    my $info_in_curl = "'".$info."'";

    my $reg_command = "curl -X POST -d ".$info_in_curl." -H 'Content-Type: application/json;charset=UTF-8' http://".$MSB_ADDR.$api_urls[$i];
    print $reg_command."\n";

    my $reg_response = `$reg_command`;

    my $rsp_json = decode_json($reg_response);
    $controller_id = $rsp_json->{$id_keynames[$i]};

    if($first) {
        print $controller_id_fh "\"".$controller_names[$i]."ID\" : "."\"".$controller_id."\"";
        $first=0;
    } else {
        print $controller_id_fh ",\n\"".$controller_names[$i]."ID\" : "."\"".$controller_id."\"";
    }
}
print $controller_id_fh "\n}";
close $controller_id_fh;
