#!/usr/bin/perl
use JSON qw( decode_json encode_json);

sub readFile {
  my ($filename) = @_;

  local $/=undef;
  open FILE, $filename or die "Couldn't open file: $!";
  my $content = <FILE>;
  close FILE;

  return $content;
}


$DATA_FILENAME = "tmp/inserted_data.json";

$MSB_IP=$ARGV[0];

my $all_objects = decode_json(readFile($DATA_FILENAME));


foreach my $obj (@$all_objects) {
    my $resource = $obj->{"resource"};
    my $id = $obj->{"id"};

    my $url = "http://$MSB_IP/openoapi/sdnobrs/v1/$resource/$id";
    my $delete_command = "curl -X DELETE -H 'Content-Type: application/json;charset=UTF-8' $url";
    print $delete_command."\n";
    system $delete_command;
}

