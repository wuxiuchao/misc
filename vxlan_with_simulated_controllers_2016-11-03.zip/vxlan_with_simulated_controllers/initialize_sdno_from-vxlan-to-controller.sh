#/bin/bash

source ./openo-docker-functions.sh

IMAGES=(common-services-msb common-services-drivermanager common-services-extsys
        sdno-service-mss sdno-service-brs
        sdno-service-overlayvpn sdno-service-vxlan
        sdno-driver-huawei-overlay)

CONTAINERS=(i-msb i-dm i-esr
            i-sdnos-mss i-sdnos-brs
            i-sdnos-overlay i-sdnos-vxlan
            i-sdnod-hw-overlay)

IPS=(172.18.0.2 172.18.0.3 172.18.0.4
     172.18.2.2 172.18.2.3 
     172.18.2.4 172.18.2.5
     172.18.3.2)

MSB_IPPORT=${IPS[0]}:80

stop=$@
if [ "$stop" == "stop" ]
then
    docker_clean_all
else
    docker_clean_all
    docker_sync_all
    docker_start_all
fi
