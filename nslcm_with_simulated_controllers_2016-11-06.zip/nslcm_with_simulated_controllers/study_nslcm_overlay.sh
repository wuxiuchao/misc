#/bin/bash

CONTAINERS=(i-msb i-dm i-esr
            i-inventory
            i-sdnos-mss i-sdnos-brs
            i-sdnos-nslcm
            )

stop=$@

i=0
len=${#CONTAINERS[*]}

while [ $i -lt $len ]; do
    container=${CONTAINERS[$i]}

    if [ "$stop" == "stop" ]
    then
        sudo docker stop $container
    else
        sudo docker start $container
        sleep 10
    fi

    let i++
done
