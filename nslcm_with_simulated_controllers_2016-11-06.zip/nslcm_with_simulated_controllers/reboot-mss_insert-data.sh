#/bin/bash

sudo docker stop i-sdnos-mss
sudo docker rm i-sdnos-mss
sudo docker run -d -t --name i-sdnos-mss --network openo-net --ip 172.18.3.2 -e MSB_ADDR=172.18.0.2 openoint/sdno-service-mss
sleep 100
./topo-data_import.pl 172.18.0.2 172.18.0.1
