#!/usr/bin/perl
use JSON qw( decode_json encode_json);

sub readFile {
  my ($filename) = @_;

  local $/=undef;
  open FILE, $filename or die "Couldn't open file $filename: $!";
  my $content = <FILE>;
  close FILE;

  return $content;
}

my @controller_names = ("AcBranchController", "AcDcController");
my @shutdown_ports = ("20001", "20002");

######################stop simulated controllers
foreach my $i (0 .. $#shutdown_ports) {
    my $stop_command = "java -jar moco-runner-0.11.0-standalone.jar shutdown -s ".$shutdown_ports[$i];
    #print $stop_command."\n";
    system $stop_command;
}
