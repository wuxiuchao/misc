#!/usr/bin/perl
use JSON qw( decode_json encode_json);

sub readFile {
  my ($filename) = @_;

  local $/=undef;
  open FILE, $filename or die "Couldn't open file: $!";
  my $content = <FILE>;
  close FILE;

  return $content;
}


$ME_ID_FILENAME = "tmp/inserted_data.json";
$TEMPLATE_FILENAME = "request_overlay-creation_from-nslcm_template.json";
$CREATION_REQUEST_FILENAME = "create.json";

my $all_ids = decode_json(readFile($ME_ID_FILENAME));

my $request = decode_json(readFile($TEMPLATE_FILENAME));


my $key = $request->{site}->{thinCpeId};
$request->{site}->{thinCpeId} = $all_ids->{$key};

$key = $request->{site}->{vCPEId};
$request->{site}->{vCPEId} = $all_ids->{$key};

$key = $request->{sfp}->{scfNeId};
$request->{sfp}->{scfNeId} = $all_ids->{$key};

$key = $request->{sfp}->{servicePathHops}[0]->{sfiId};
$request->{sfp}->{servicePathHops}[0]->{sfiId} = $all_ids->{$key};

$key = $request->{sfp}->{servicePathHops}[1]->{sfiId};
$request->{sfp}->{servicePathHops}[1]->{sfiId} = $all_ids->{$key};

my $new_request = encode_json($request);

open(my $output, '>', $CREATION_REQUEST_FILENAME) or die "Could not open file: $!";
print $output $new_request;
close $output;
