sudo docker stop i-catalog
sudo docker rm i-catalog
sudo docker run -d -t --name i-catalog --network openo-net --ip 172.18.1.2 -e MSB_ADDR=172.18.0.2 openoint/common-tosca-catalog:1.0.0
