1. create and start all dockers for study vxlan
./initialize_sdno_from-vxlan-to-controller.sh

after that, study_containers_from-vxlan-to-controller.sh should be used for start/stop all containers.

2. start controller moco server
./start-controllers.pl

3. register controller moco server to ESR
./register-controllers.pl MSB SELF

the same term window can be used to check requests received by Moco server.

4. import topology data into BRS
./import_topo-data.pl MSB

5. apply the hack on HW overlay driver
https://wiki.open-o.org/view/Provision_and_Activate_SDN-O_VxLAN

6. change creation_fullmesh.json with the id returned when creating ME in BRS

8. use firefox to open this https moco server (Huawei overlay driver) and accept its self-signed cert.

9. use postman to send creation request (body is the content of creation_fullmesh.json).

