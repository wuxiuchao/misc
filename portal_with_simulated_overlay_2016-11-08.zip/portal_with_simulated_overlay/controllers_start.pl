#!/usr/bin/perl
use JSON qw( decode_json encode_json);

sub readFile {
  my ($filename) = @_;

  local $/=undef;
  open FILE, $filename or die "Couldn't open file $filename: $!";
  my $content = <FILE>;
  close FILE;

  return $content;
}



my @controller_names = ("AcBranchController", "AcDcController");
my @ports = ("10001", "10002");
my @shutdown_ports = ("20001", "20002");

foreach my $i (0 .. $#controller_names) {
    ##############merge all request-response pairs into one json file to be used by moco-server.
    #my $out_fn = "tmp/".$controller_names[$i].".json";
    #open(my $out_fh, '>', $out_fn) or die "Could not open file: $!";
    #print $out_fh "[\n";

    #my @all_simu_filenames = glob($controller_names[$i].'/*.json');
    #foreach my $j (0 .. $#all_simu_filenames) {
    #    my $content = readFile($all_simu_filenames[$j]);
    #    if($j==$#all_simu_filenames) {
    #        print $out_fh $content."\n";
    #    } else {
    #        print $out_fh $content.",\n";
    #    }
    #}
    #print $out_fh "]";
    #close $out_fn;

    ###############start the moco server
    my $simu_fn = "simulation/".$controller_names[$i].".json";
    my $logfile_name = "tmp/".$controller_names[$i]."_log.json";
    my $run_command = "java -jar moco-runner-0.11.0-standalone.jar ";
    if($controller_names[$i] eq "AcBranchController") {
        $run_command = $run_command."https -p ".$ports[$i]." -c ".$simu_fn." -s ".$shutdown_ports[$i]." --https cert.jks --cert mocohttps --keystore mocohttps >".$logfile_name." &";
    } else {
        $run_command = $run_command."http -p ".$ports[$i]." -c ".$simu_fn." -s ".$shutdown_ports[$i]." >".$logfile_name." &";
    }

    print $run_command."\n";
    system $run_command;
    sleep(3);

}
