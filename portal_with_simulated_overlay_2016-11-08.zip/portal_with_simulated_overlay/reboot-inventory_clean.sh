sudo docker stop i-inventory
sudo docker rm i-inventory
sudo docker run -d -t --name i-inventory --network openo-net --ip 172.18.1.3 -e MSB_ADDR=172.18.0.2 openoint/common-tosca-inventory:1.0.0
