#!/usr/bin/perl
use JSON qw( decode_json encode_json);

sub readFile {
  my ($filename) = @_;

  local $/=undef;
  open FILE, $filename or die "Couldn't open file $filename: $!";
  my $content = <FILE>;
  close FILE;

  return $content;
}



$MSB_ADDR=$ARGV[0];
$SIMULATOR_IP=$ARGV[1];


$OVERLAY_SIMU_FILENAME = "OverlayMoco/overlay-moco.json";
$OVERLAY_REG_FILENAME = "OverlayMoco/overlay-reg.json";
$OVERLAY_PLACE_HOLDER = "OVERLAY_IP";


$OVERLAY_LISTEN_PORT = "8503";
$OVERLAY_SHUTDOWN_PORT = "28503";

my $msb_url = "/openoapi/microservices/v1/services";


##############start overlay moco
my $run_command = "java -jar moco-runner-0.11.0-standalone.jar http -p ".$OVERLAY_LISTEN_PORT." -c ".$OVERLAY_SIMU_FILENAME." -s ".$OVERLAY_SHUTDOWN_PORT." >tmp/overlay.log &";
print $run_command."\n";
system $run_command;
sleep(3);


##############Register SFC Driver to Driver Manager
my $overlay_content = readFile($OVERLAY_REG_FILENAME);
$overlay_content =~ s/$OVERLAY_PLACE_HOLDER/$SIMULATOR_IP/;
my $overlay_content_in_curl = "'".$overlay_content."'";

my $overlay_reg_command = "curl -X POST -d ".$overlay_content_in_curl." -H 'Content-Type: application/json;charset=UTF-8' http://".$MSB_ADDR.$msb_url;
print $overlay_reg_command."\n";

my $overlay_reg_response = `$overlay_reg_command`;
print $overlay_reg_response."\n";


