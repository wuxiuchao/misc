#/bin/bash

source ./openo-docker-functions.sh

CONTAINERS=(i-msb i-dm i-esr i-auth i-protocolstack
            i-catalog i-inventory i-wso2ext i-aria i-model-designer 
            i-gso-gateway i-gso-manager
            i-sdnos-mss i-sdnos-brs
            i-sdnos-nslcm i-sdnos-overlay i-sdnos-sfc i-sdnos-vpc i-sdnos-vxlan i-sdnos-ipsec
            i-sdnos-monitor i-sdnos-optimize i-sdnos-l2vpn i-sdnos-l3vpn i-sdnos-vsitemgr
            i-sdnod-hw-openstack i-sdnod-hw-overlay i-sdnod-hw-sfc
            i-sdnod-ct-te i-sdnod-hw-l3vpn i-sdnod-zte-sptn
            )


IMAGES=(common-services-msb:1.0.0 common-services-drivermanager:1.0.0 common-services-extsys:1.0.0 common-services-auth:1.0.0 common-services-protocolstack:1.0.0 
        common-tosca-catalog:1.0.0 common-tosca-inventory:1.0.0 common-services-wso2ext:1.0.0 common-tosca-aria:1.0.0 common-tosca-modeldesigner:1.0.0
        gso-service-gateway:1.0.0 gso-service-manager:1.0.0
        sdno-service-mss:1.0.0 sdno-service-brs:1.0.0
        sdno-service-nslcm:1.0.0 sdno-service-overlayvpn:1.0.0 sdno-service-servicechain:1.0.0 sdno-service-vpc:1.0.0 sdno-service-vxlan:1.0.0 sdno-service-ipsec:1.0.0
        sdno-monitoring:1.0.0 sdno-optimize:1.0.0 sdno-service-l2vpn:1.0.0 sdno-service-l3vpn:1.0.0 sdno-vsitemgr:1.0.0
        sdno-driver-huawei-openstack:1.0.0 sdno-driver-huawei-overlay:1.0.0 sdno-driver-huawei-servicechain:1.0.0
        sdno-driver-ct-te:1.0.0 sdno-driver-huawei-l3vpn:1.0.0 sdno-driver-zte-sptn:1.0.0
        )



IPS=(172.18.0.2 172.18.0.3 172.18.0.4  172.18.0.5 172.18.0.6
     172.18.1.2 172.18.1.3 172.18.1.4  172.18.1.5 172.18.1.6
     172.18.2.2 172.18.2.3 
     172.18.3.2 172.18.3.3 
     172.18.4.2 172.18.4.3 172.18.4.4 172.18.4.5 172.18.4.6 172.18.4.7
     172.18.5.2 172.18.5.3 172.18.5.4 172.18.5.5 172.18.5.6
     172.18.6.2 172.18.6.3 172.18.6.4
     172.18.7.2 172.18.7.3 172.18.7.4)

MSB_IPPORT=172.18.0.2:80
NSLCM_MYSQL_ADDR=172.18.1.3:3306

stop=$@
if [ "$stop" == "stop" ]
then
    docker_clean_all
else
    docker_clean_all
#    docker_sync_all
    docker_start_once_for_all
    sudo docker stop $(sudo docker ps -a -q)
fi
