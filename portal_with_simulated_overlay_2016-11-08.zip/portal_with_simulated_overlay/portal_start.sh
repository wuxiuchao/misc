#/bin/bash

latest=$@
guipackage="open-o/source-code/gso-gui/openo-portal/portal-package/target/openoui/"

cur=$(pwd)
echo $cur

echo "-------------- Try to stop firstly ----------"
cd portal/bin
./stop.sh
sleep 10

cd


if [ "$latest" == "latest" ]
then
    echo "--------------- Get latest website since latest is specified ---------- "
    rm -f -r portal/logs/*
    rm -f -r portal/webapps/ROOT/openoui/portal/*

    cp -r $guipackage"catalog" portal/webapps/ROOT/openoui/portal/catalog
    cp -r $guipackage"common" portal/webapps/ROOT/openoui/portal/common
    cp -r $guipackage"extsys" portal/webapps/ROOT/openoui/portal/extsys
    cp -r $guipackage"lifecyclemgr" portal/webapps/ROOT/openoui/portal/lifecyclemgr
    cp -r $guipackage"resmgr-nfv" portal/webapps/ROOT/openoui/portal/resmgr-nfv
    cp -r $guipackage"resmgr-sdn" portal/webapps/ROOT/openoui/portal/resmgr-sdn
    cp -r $guipackage"user" portal/webapps/ROOT/openoui/portal/user
    cp -r $guipackage"performance" portal/webapps/ROOT/openoui/portal/performance

fi

echo "-------------- Start the portal ----------"
cd $cur
cd portal/bin
./start.sh
