#!/usr/bin/perl

sub readFile {
  my ($filename) = @_;

  local $/=undef;
  open FILE, $filename or die "Couldn't open file $filename: $!";
  my $content = <FILE>;
  close FILE;

  return $content;
}



$MSB_ADDR=$ARGV[0];
$PORTAL_IP=$ARGV[1];


$PORTAL_REG_FILENAME = "registration/Reg_portal.json";
$PORTAL_IP_PLACE_HOLDER = "PORTAL_IP";


my $msb_url = "/api/microservices/v1/iuiRoute";




##############Register Portal to MSB
my $portal_content = readFile($PORTAL_REG_FILENAME);
$portal_content =~ s/$PORTAL_IP_PLACE_HOLDER/$PORTAL_IP/;
my $portal_content_in_curl = "'".$portal_content."'";

my $portal_reg_command = "curl -X POST -d ".$portal_content_in_curl." -H 'Content-Type: application/json;charset=UTF-8' http://".$MSB_ADDR.$msb_url;
print $portal_reg_command."\n";

my $portal_reg_response = `$portal_reg_command`;
print $portal_reg_response."\n";


