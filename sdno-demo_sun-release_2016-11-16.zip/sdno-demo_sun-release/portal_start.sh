#/bin/bash

cur=$(pwd)

echo "-------------- Try to stop firstly ----------"
cd portal/bin
./stop.sh
sleep 10


echo "-------------- Start the portal ----------"
cd $cur
cd portal/bin
./start.sh

cd $cur