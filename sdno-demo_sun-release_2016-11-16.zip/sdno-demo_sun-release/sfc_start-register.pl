#!/usr/bin/perl
use JSON qw( decode_json encode_json);

sub readFile {
  my ($filename) = @_;

  local $/=undef;
  open FILE, $filename or die "Couldn't open file $filename: $!";
  my $content = <FILE>;
  close FILE;

  return $content;
}



$MSB_ADDR=$ARGV[0];
$SIMULATOR_IP=$ARGV[1];


$SFC_DRIVER_SIMU_FILENAME = "simulation/SfcDriver.json";
$DRIVER_LISTEN_PORT = "8542";
$DRIVER_SHUTDOWN_PORT = "18542";

$SFC_DRIVER_REG_FILENAME = "registration/Reg_SfcDriver.json";
$DRIVER_PLACE_HOLDER = "DRIVER_IP";
my $dm_url = "/openoapi/drivermgr/v1/drivers";




$logfile_name = "tmp/SfcDriver_log.txt";
##############start the driver for SFC
my $run_command = "java -jar moco-runner-0.11.0-standalone.jar http -p ".$DRIVER_LISTEN_PORT." -c ".$SFC_DRIVER_SIMU_FILENAME." -s ".$DRIVER_SHUTDOWN_PORT." >".$logfile_name." &";
print $run_command."\n";
system $run_command;
sleep(3);


##############Register SFC Driver to Driver Manager
my $driver_content = readFile($SFC_DRIVER_REG_FILENAME);
$driver_content =~ s/$DRIVER_PLACE_HOLDER/$SIMULATOR_IP/;
my $driver_content_in_curl = "'".$driver_content."'";

my $driver_reg_command = "curl -X POST -d ".$driver_content_in_curl." -H 'Content-Type: application/json;charset=UTF-8' http://".$MSB_ADDR.$dm_url;
print $driver_reg_command."\n";

my $driver_reg_response = `$driver_reg_command`;
print $driver_reg_response."\n";