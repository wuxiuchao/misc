This document describes how to study Open-O (w/o NFV-O) from portal with simulated controllers and simulated SFC driver (before simulating its controllers with twisted).
We assume that one VM (Ubuntu) has been installed on your laptop and dockers will be run in the VM.


Prerequisite:
1. docker has been installed on this VM.
2. JSON module for perl is installed: sudo apt install libjson-perl
3. Open-O portal source code has been checked out and build in the VM. 
   For simplicity, you can also complete these tasks on other computers and copy into this VM.  However, it is troublesome if you want to use the latest portal.

Steps to start Open-O and its portal.
1. start microservices needed by Open-O (w/o NFV-O).
./study_openo_from-portal-to-controller.sh

2. start moco servers for controllers and register to ESR. You need check the IP used by MSB container and the IP of the VM on the docker's network 
./start-register-controllers.pl MSB-ADDR VM-IP-IN-DOCKER

3. start moco server for SFC driver, register to driver manager, and register non-existing controllers to ESR
./start-register-sfc.pl MSB-ADDR VM-IP-IN-DOCKER

4. import topo data into BRS 
./import_topo-data.pl MSB-ADDR

5. start Open-O portal webserver: Note that you need change the script to specify the path of "gso-gui" repository.
./start_portal.sh

6. register Open-O portal to MSB. (under the "IUI" tab)


NOTE: the content of many json files still need to be tuned for demonstration. 
