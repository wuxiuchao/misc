#!/usr/bin/perl
use JSON qw( decode_json encode_json);


sub readFile {
  my ($filename) = @_;

  local $/=undef;
  open FILE, $filename or die "Couldn't open file: $!";
  my $content = <FILE>;
  close FILE;

  return $content;
}

sub getId {
  my ($rsp, $type, $prefix) = @_;

  if($type eq "Controller") {
    return $rsp;
  } else {
    my $rsp_obj = decode_json($rsp);
    my $id = $rsp_obj->{$prefix}->{"id"};
    return $id;
  }
}



$ID_FILENAME = "tmp/controller-id.json";
$CREATED_DATA_FILENAME = "tmp/inserted_data.json";


#my @types = ("Site", "Controller", "ManagedElement", "LogicalTerminationPoint");
#my @json_prefixes = ("site", "controller", "managedElement", "logicalTerminationPoint");
#my @api_resources = ("sites", "controller", "managed-elements", "logical-termination-points");

my @types = ("ManagedElement");
my @json_prefixes = ("managedElement");
my @api_resources = ("managed-elements");

my @controller_names = ("AcBranchController", "AcWanController", "AcDcController");


$MSB_IP=$ARGV[0];


my $all_controller_ids = decode_json(readFile($ID_FILENAME));

open(my $output_fh, '>', $CREATED_DATA_FILENAME) or die "Could not open file: $!";
print $output_fh "[\n";

my $first=1;
foreach my $i (0 .. $#types) {
  my $all_objects = decode_json(readFile("topo/".$types[$i].".json"));

  for my $obj (@$all_objects) {
      my $obj_str = encode_json($obj);

      ###########################replace with real controller_id
      if($files[$i] eq "ManagedElement.json") {
          foreach my $j (0 .. $#controller_names) {
              my $controller_name = $controller_names[$j];
              my $controller_id = $all_controller_ids->{$controller_name};
              $obj_str =~ s/$controller_name/$controller_id/;
          }
      }


      my $data_in_command = "'{\"$json_prefixes[$i]\":".$obj_str."}'";
      $data_in_command =~ tr{\n}{ };

      my $url = "http://$MSB_IP/openoapi/sdnobrs/v1/$api_resources[$i]";

      my $insert_command = "curl -X POST -d $data_in_command -H 'Content-Type: application/json;charset=UTF-8' $url";
      #print $insert_command."\n";
      my $response = `$insert_command`;
      print $response."\n";

      my $id = getId($response, $types[$i], $json_prefixes[$i]);
      if($first) {
          print $output_fh "{"."\"resource\":"."\"".$api_resources[$i]."\", \"id\": "."\"".$id."\"}";
          $first=0;
      } else {
          print $output_fh ",\n{"."\"resource\":"."\"".$api_resources[$i]."\", \"id\": "."\"".$id."\"}";
      }
  }
}
print $output_fh "\n]";
close $output_fh;
