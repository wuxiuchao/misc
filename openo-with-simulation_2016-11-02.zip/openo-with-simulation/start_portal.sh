#/bin/bash

latest=$@
guipackage="open-o/source-code/gso-gui"

echo "-------------- Try to stop firstly ----------"
cd portal/bin
./stop.sh
sleep 10

cd


if [ "$latest" == "latest" ]
then
    echo "--------------- Get latest website since purge is specified ---------- "
    rm -f -r portal/logs/*
    rm -f -r portal/webapps/ROOT/openoui/portal/*

    cp -r $guipackage"/openo-portal/portal-package/target/openo-portal/catalog" portal/webapps/ROOT/openoui/portal/catalog
    cp -r $guipackage"/openo-portal/portal-package/target/openo-portal/common" portal/webapps/ROOT/openoui/portal/common
    cp -r $guipackage"/openo-portal/portal-package/target/openo-portal/extsys" portal/webapps/ROOT/openoui/portal/extsys
    cp -r $guipackage"/openo-portal/portal-package/target/openo-portal/lifecyclemgr" portal/webapps/ROOT/openoui/portal/lifecyclemgr
    cp -r $guipackage"/openo-portal/portal-package/target/openo-portal/resmgr-nfv" portal/webapps/ROOT/openoui/portal/resmgr-nfv
    cp -r $guipackage"/openo-portal/portal-package/target/openo-portal/resmgr-sdn" portal/webapps/ROOT/openoui/portal/resmgr-sdn
    cp -r $guipackage"/openo-portal/portal-package/target/openo-portal/user" portal/webapps/ROOT/openoui/portal/user

fi

echo "-------------- Start the portal ----------"
cd portal/bin
./start.sh
