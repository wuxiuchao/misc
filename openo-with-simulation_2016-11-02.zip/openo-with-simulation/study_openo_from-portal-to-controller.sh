#/bin/bash

source ./openo-docker-functions.sh

#SFC driver will be simulated before its controllers/physical devices could be simulated with twisted (http://www.devshed.com/c/a/Python/SSH-with-Twisted/).
IMAGES=(common-services-msb common-services-drivermanager common-services-extsys common-services-auth common-services-protocolstack common-tosca-catalog common-tosca-inventory common-services-wso2ext
        gso-service-gateway gso-service-manager
        sdno-service-mss sdno-service-brs
        sdno-service-nslcm sdno-service-overlayvpn sdno-service-servicechain sdno-service-vpc sdno-service-vxlan sdno-service-ipsec sdno-service-l2vpn sdno-service-l3vpn
        sdno-driver-huawei-l3vpn sdno-driver-huawei-openstack sdno-driver-huawei-overlay sdno-driver-zte-sptn)

CONTAINERS=(i-msb i-dm i-esr i-auth i-protocolstack i-catalog i-inventory i-wso2ext
            i-gso-gateway i-gso-manager
            i-sdnos-mss i-sdnos-brs
            i-sdnos-nslcm i-sdnos-overlay i-sdnos-sfc i-sdnos-vpc i-sdnos-vxlan i-sdnos-ipsec i-sdnos-l2vpn i-sdnos-l3vpn
            i-sdnod-hw-l3vpn i-sdnod-hw-openstack i-sdnod-hw-overlay i-sdnod-zte-sptn)

stop=$@
if [ "$stop" == "stop" ]
then
    docker_clean_all
else
    docker_clean_all
    docker_sync_all
    docker_start_all
fi
