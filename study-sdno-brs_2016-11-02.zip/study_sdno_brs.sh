#/bin/bash

source ./openo-docker-functions.sh

IMAGES=(common-services-msb sdno-service-mss sdno-service-brs)

CONTAINERS=(i-msb i-sdnos-mss i-sdnos-brs)

stop=$@
if [ "$stop" == "stop" ]
then
    docker_clean_all
else
    docker_clean_all
    docker_sync_all
    docker_start_all
fi
