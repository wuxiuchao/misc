#!/usr/bin/perl
use JSON qw( decode_json encode_json);

sub readFile {
  my ($filename) = @_;

  local $/=undef;
  open FILE, $filename or die "Couldn't open file $filename: $!";
  my $content = <FILE>;
  close FILE;

  return $content;
}


$MSB_ADDR=$ARGV[0];

$ID_FILENAME = "tmp/controller-id.json";
$SHUTDOWN_FILENAME = "tmp/shutdown.txt";

my @controller_names = ("AcBranchController", "AcDcController");
my @api_urls = ("/openoapi/extsys/v1/sdncontrollers", "/openoapi/extsys/v1/vims");

######################stop simulated controllers
my $port_str = readFile($SHUTDOWN_FILENAME);
#print $content."\n";
my @ports = @abc = split(' ', $port_str);
foreach my $i (0 .. $#ports) {
    my $stop_command = "java -jar moco-runner-0.11.0-standalone.jar shutdown -s ".$ports[$i];
    #print $stop_command."\n";
    system $stop_command;
}

#####################delete controller information in ESR
my $controller_file_content = readFile($ID_FILENAME);
my $controllers = decode_json($controller_file_content);
foreach my $i (0 .. $#controller_names) {
    my $id = $controllers->{$controller_names[$i]};
    if($id) {
        my $delete_command = "curl -X DELETE "." http://".$MSB_ADDR.$api_urls[$i]."/".$id;
        #print $delete_command."\n";
        system $delete_command;
    }
}
