#!/usr/bin/perl
use JSON qw( decode_json encode_json);

sub readFile {
  my ($filename) = @_;

  local $/=undef;
  open FILE, $filename or die "Couldn't open file $filename: $!";
  my $content = <FILE>;
  close FILE;

  return $content;
}



$MSB_ADDR=$ARGV[0];
$SIMULATOR_IP=$ARGV[1];


$CATALOG_SIMU_FILENAME = "CatalogMoco/catalog-moco.json";
$CATALOG_REG_FILENAME = "CatalogMoco/catalog-reg.json";
$CATALOG_PLACE_HOLDER = "CATALOG_IP";


$CATALOG_LISTEN_PORT = "8200";
$CATALOG_SHUTDOWN_PORT = "28200";

my $msb_url = "/openoapi/microservices/v1/services";


##############start catalog moco
my $run_command = "java -jar moco-runner-0.11.0-standalone.jar http -p ".$CATALOG_LISTEN_PORT." -c ".$CATALOG_SIMU_FILENAME." -s ".$CATALOG_SHUTDOWN_PORT." >tmp/catalog.log &";
print $run_command."\n";
system $run_command;
sleep(3);


##############Register SFC Driver to Driver Manager
my $catalog_content = readFile($CATALOG_REG_FILENAME);
$catalog_content =~ s/$CATALOG_PLACE_HOLDER/$SIMULATOR_IP/;
my $catalog_content_in_curl = "'".$catalog_content."'";

my $catalog_reg_command = "curl -X POST -d ".$catalog_content_in_curl." -H 'Content-Type: application/json;charset=UTF-8' http://".$MSB_ADDR.$msb_url;
print $catalog_reg_command."\n";

my $catalog_reg_response = `$catalog_reg_command`;
print $catalog_reg_response."\n";


