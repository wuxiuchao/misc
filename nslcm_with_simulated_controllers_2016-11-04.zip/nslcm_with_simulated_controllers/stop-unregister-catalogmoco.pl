#!/usr/bin/perl
use JSON qw( decode_json encode_json);

sub readFile {
  my ($filename) = @_;

  local $/=undef;
  open FILE, $filename or die "Couldn't open file $filename: $!";
  my $content = <FILE>;
  close FILE;

  return $content;
}


$MSB_ADDR=$ARGV[0];
$SIMULATOR_IP=$ARGV[1];




$CATALOG_LISTEN_PORT = "8200";
$CATALOG_SHUTDOWN_PORT = "28200";

my $msb_url = "/openoapi/microservices/v1/services";

##############stop the catalog moco
my $stop_command = "java -jar moco-runner-0.11.0-standalone.jar shutdown -s ".$CATALOG_SHUTDOWN_PORT;
print $stop_command."\n";
system $stop_command;

##############Unregister catalog  moco from msb

my $catalog_unreg_command = "curl -X DELETE "."http://".$MSB_ADDR.$msb_url."/catalog/version/v1/nodes/".$SIMULATOR_IP."/".$CATALOG_LISTEN_PORT;
print $catalog_unreg_command."\n";

my $calalog_unreg_response = `$catalog_unreg_command`;
print $catalog_unreg_response."\n";
