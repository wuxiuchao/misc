#!/usr/bin/perl
use JSON qw( decode_json encode_json);

sub readFile {
  my ($filename) = @_;

  local $/=undef;
  open FILE, $filename or die "Couldn't open file $filename: $!";
  my $content = <FILE>;
  close FILE;

  return $content;
}



$ID_OUTPUT_FILENAME = "tmp/controller-id.json";
$SHUTDOWN_OUTPUT_FILENAME = "tmp/shutdown.txt";


my @controller_names = ("AcBranchController", "AcDcController");
my @ports = ("10001", "10002");
my @shutdown_ports = ("20001", "20002");
my @api_urls = ("/openoapi/extsys/v1/sdncontrollers", "/openoapi/extsys/v1/vims");
my @id_keynames = ("sdnControllerId", "vimId");



open(my $shutdown_fh, '>', $SHUTDOWN_OUTPUT_FILENAME) or die "Could not open file: $!";



$first=1;
foreach my $i (0 .. $#controller_names) {
    ##############merge all request-response pairs into one json file to be used by moco-server.
    my $out_fn = "tmp/".$controller_names[$i].".json";
    open(my $out_fh, '>', $out_fn) or die "Could not open file: $!";
    print $out_fh "[\n";

    my @all_simu_filenames = glob($controller_names[$i].'/*.json');
    foreach my $j (0 .. $#all_simu_filenames) {
        my $content = readFile($all_simu_filenames[$j]);
        if($j==$#all_simu_filenames) {
            print $out_fh $content."\n";
        } else {
            print $out_fh $content.",\n";
        }
    }
    print $out_fh "]";
    close $out_fn;

    ###############start the moco server
    my $logfile_name = "tmp/".$controller_names[$i]."_log.json";
    my $run_command = "java -jar moco-runner-0.11.0-standalone.jar ";
    if($controller_names[$i] eq "AcBranchController") {
        $run_command = $run_command."http -p ".$ports[$i]." -c ".$out_fn." -s ".$shutdown_ports[$i]." >".$logfile_name." &";
    } else {
        $run_command = $run_command."https -p ".$ports[$i]." -c ".$out_fn." -s ".$shutdown_ports[$i]." --https cert.jks --cert mocohttps --keystore mocohttps >".$logfile_name." &";
    }

    print $run_command."\n";
    system $run_command;
    print $shutdown_fh "$shutdown_ports[$i] ";
    sleep(3);

}
close $shutdown_fh;
